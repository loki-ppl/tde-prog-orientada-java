/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diablo4;

import java.util.ArrayList;

/**
 *
 * @author augusto.coelho
 */
public class Inventario {
    protected ArrayList<Item> itensDefesa;
    protected ArrayList<Item> itensAtaque;
    
    public void addItem(Item item){
        if (item.getIdItem()% 2 == 0){
            
        }
        else{
            
        }
    }
    
}
